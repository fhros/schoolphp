<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method="get" action="testi24.2.php">
        <input type="number" name="input1">
        <input type="number" name="input2">
        <button>paina</button>
    </form>
    <?php
    ?>
</body>
</html>