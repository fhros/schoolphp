<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color: #66FF99">
<form action="testi25.2.php" method="post">
    <p>Valitse allaolevasta ilistasta haluamasi kappaleet</p>
    <select multiple size="20" name="select[]">
        <option value="hinta1">Old before I die</option>
        <option value="hinta2">Lazy Days</option>
        <option value="hinta2">Angels</option>
        <option value="hinta1">Let me entertain you</option>
        <option value="hinta1">Millenium</option>
        <option value="hinta2">No regrets</option>
        <option value="hinta2">Strong</option>
        <option value="hinta1">She's the one</option>
        <option value="hinta1">RockDJ</option>
        <option value="hinta2">Kids</option>
        <option value="hinta2">Supreme</option>
        <option value="hinta1">Let love be your energy</option>
        <option value="hinta2">Eternity</option>
        <option value="hinta1">The road to Mandalay</option>
        <option value="hinta2">Feel</option>
        <option value="hinta1">Come undone</option>
        <option value="hinta2">Sexed Up</option>
        <option value="hinta1">Radio</option>
        <option value="hinta1">Misundestood</option>
    </select>
    <p>Valinna jälkeen siirry ostamaan kappaleet <input type="submit" value="Osta valitut"></input></p>
    
</form>
</body>
</html>